﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HousetaxBillingSystem.Models;
using HousetaxBillingSystem.ViewModels;
using Rotativa;
using System.Net.Mail;

namespace HousetaxBillingSystem.Controllers
{
    public class CustomerBillController : Controller
    {
        private readonly masterEntities db = new masterEntities();

        public ActionResult Login()
        {
            return View();
        }
        public ActionResult DashBoard()
        {
            int CountforPaid = db.Bills.Where(a => a.status == "Paid" && (a.billDate.Month == DateTime.Now.Month && a.billDate.Year == DateTime.Now.Year) ).Count();
            ViewBag.CountforPaid = CountforPaid;
            int CountforNotPaid = db.Bills.Where(a => a.status == "Pending" && (a.billDate.Month == DateTime.Now.Month && a.billDate.Year == DateTime.Now.Year)).Count();
            ViewBag.CountforNotPaid = CountforNotPaid;
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginDetail adminDetail)
        {
            var isAdmin = db.LoginDetails.Where(a => a.username == adminDetail.username).SingleOrDefault();
            if (isAdmin != null)
            {
                if (isAdmin.password == adminDetail.password)
                {
                    return RedirectToAction("DashBoard");
                }
                ModelState.AddModelError("password", "Password incorrect");
            }
            else
            {
                ModelState.AddModelError("username", "Username incorrect");
            }
            return View(adminDetail);
        }

        // GET: CustomerBill
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult customerRegister()
        {
            var res = db.CustomerDetails.Count();
            ViewBag.customerId = 1001 + res;
            return View();
        }

        [HttpPost]
        public ActionResult customerRegister(CustomerDetail customerDetail)
        {
            if (ModelState.IsValid)
            {
                db.CustomerDetails.Add(customerDetail);
                db.SaveChanges();
                var res1 = db.CustomerDetails.Count();
                ViewBag.customerId = 1001 + res1;
                return Content("<html><head><script>alert('Successfully Registered'); window.location.href = '/CustomerBill/customerRegister'</script></head></html>");
            }
            ModelState.Clear();
            var res = db.CustomerDetails.Count();
            ViewBag.customerId = 1001 + res;
            return View();
        }

        public ActionResult searchCustomerDetails()
        {
            var res = db.CustomerDetails.ToList();
            return View(res);
        }

        [HttpGet]
        public ActionResult GetCustomers()
        {
            var res = (from obj in db.CustomerDetails select new { customerid = obj.customerId, customername = obj.customerName, houseType = obj.houseType, houseNo = obj.houseNo, mobileNumber = obj.mobileNumber, builtInArea = obj.builtInArea,  area = obj.area, Location = obj.Location, pincode = obj.pincode,Email=obj.email }).ToList();
            return Json(new { data = res }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetBills()
        {
            var res = (from obj in db.Bills select new { billid = obj.billId, customerid = obj.customerId, customername = obj.CustomerDetail.customerName, billdate = obj.billDate, billduedate = obj.billDueDate, billamount = obj.billAmount, status = obj.status }).ToList();
            return Json(new { data = res }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult searchCustomerDetails(int? customerId)
        {
            List<CustomerDetail> res = null;
            if (customerId != null)
            {
                res = db.CustomerDetails.Where(a => a.customerId == customerId).ToList();
                return View(res);
            }
            res = db.CustomerDetails.ToList();
            return View();
        }

        public ActionResult editCustomerDetails(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CustomerDetail customerDetail = db.CustomerDetails.Find(id);
            if (customerDetail == null)
            {
                return HttpNotFound();
            }
            return View(customerDetail);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult editCustomerDetails([Bind(Include = "customerId,customerName,mobileNumber,email,houseNo,houseType,builtInArea,areaInSqfts,area,Location,pincode")] CustomerDetail customerDetail)
        {
            if (ModelState.IsValid)
            {
                db.Entry(customerDetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("searchCustomerDetails");
            }
            return View(customerDetail);
        }

        public ActionResult generateBill(int? id)
        {
            CustomerDetail customer = db.CustomerDetails.Find(id);
            var bill = db.Bills.Where(a => a.customerId == id).ToList();
            bool toGenerate = false;
            if (bill != null)
            {
                foreach (var item in bill)
                {
                    if (item.billDate.Month == DateTime.Now.Month && item.billDate.Year == DateTime.Now.Year)
                    {
                        toGenerate = true;
                    }
                }
            }
            if (!toGenerate)
            {
                string area = customer.area;
                string houseType = customer.houseType;
                string builtInArea = customer.builtInArea;
                int billId = db.Bills.Count();
                var price = db.Prices.Where(a => a.area == area && a.builtInArea == builtInArea && a.houseType == houseType).SingleOrDefault();
                string dueDate = DateTime.Now.Month.ToString() + "/" + "20" + "/" + DateTime.Now.Year.ToString() + " 00:00:00 AM";
                CustomerBillPrice billPrice = new CustomerBillPrice()
                {
                    customerId = customer.customerId,
                    customerName = customer.customerName,
                    Area = customer.area,
                    builtinArea = customer.builtInArea,
                    areainsqft = customer.areaInSqfts,
                    houseType = customer.houseType,
                    price = price.pricepersqft * customer.areaInSqfts,
                    BillId = billId + 10000,
                    billDate = DateTime.Now.Date,
                    billDueDate = DateTime.Parse(dueDate).Date
                };
                return View(billPrice);
            }
            return Content("<html><head><script>alert('Bill Already generated for this Month'); window.location.href = '/CustomerBill/searchCustomerDetails'</script></head></html>");
        }

        public ActionResult saveBillDetails(CustomerBillPrice customerBillPrice)
        {
            Bill bill = new Bill();
            bill.billDate = DateTime.Now.Date;
            string dueDate = DateTime.Now.Month.ToString() + "/" + "30" + "/" + DateTime.Now.Year.ToString() + " 00:00:00 AM";
            bill.billDueDate = DateTime.Parse(dueDate).Date;
            bill.billAmount = customerBillPrice.price;
            bill.customerId = customerBillPrice.customerId;
            bill.status = "Pending";
            bill.fine = 0;
            db.Bills.Add(bill);
            db.SaveChanges();
            return Content("<html><head><script>alert('Bill Successfully Generated'); window.location.href = '/CustomerBill/trackBills'</script></head></html>");
        }

        public ActionResult payBills()
        {
            var res = db.Bills.Where(a => a.status == "Pending").ToList();
            return View(res);
        }

        [HttpPost]
        public ActionResult payBills(int? billId)
        {
            List<Bill> res = null;
            if (billId != null)
            {
                res = db.Bills.Where(a => a.billId == billId && a.status == "Pending").ToList();
                return View(res);
            }
            res = db.Bills.Where(a => a.status == "Pending").ToList();
            return View();
        }

        public ActionResult amountSummary(int? id)
        {
            var res = db.Bills.Where(a => a.billId == id).ToList();
            if (DateTime.Now.Date > res[0].billDueDate)
            {
                double overduedays = (DateTime.Now.Date - res[0].billDueDate).TotalDays;
                res[0].fine = Convert.ToInt32(overduedays) * 10;
            }
            ViewBag.Total = res[0].billAmount + res[0].fine;
            return View(res);
        }

        public ActionResult updatePayStatus(int? id, int? fine, string email)
        {
            var bill = db.Bills.Where(a => a.billId == id).SingleOrDefault();
            bill.status = "Paid";
            bill.fine = fine;
            Report newReport = new Report() { customerId = bill.customerId, billNo = bill.billId };
            db.Reports.Add(newReport);
            db.Entry(bill).State = EntityState.Modified;
            string msg = $"Successfully Bill Paid for Date {bill.billDate} Amount of Rs {bill.billAmount}";
            string subject = $"Bill Paid Successfully";
            sendEmail(email, subject, msg);
            db.SaveChanges();
            return Content("<html><head><script>alert('Bill Successfully Paid'); window.location.href = '/CustomerBill/trackBills'</script></head></html>");
            //return RedirectToAction("trackBills");
        }

        public ActionResult trackBills()
        {
            var res = db.Bills.ToList();
            return View(res);
        }

        public ActionResult PrintAllReport()
        {
            var report = new ActionAsPdf("reportforPaidCustomer");
            return report;
        }

        public ActionResult reportforPaidCustomer()
        {
            var res = db.Bills.Where(a => a.status == "Paid").ToList();
            var alltransactions = db.Reports.ToList();
            List<TransactionBills> trBillsList = new List<TransactionBills>();
            foreach (var item in res)
            {
                foreach (var item1 in alltransactions)
                {
                    if (item.billId == item1.billNo)
                    {
                        TransactionBills trBills = new TransactionBills();
                        trBills.CustomerId = item1.customerId;
                        trBills.CustomerName = item.CustomerDetail.customerName;
                        trBills.TransactionId = item1.transactionId;
                        trBills.Status = item.status;
                        trBills.BillId = item.billId;
                        trBills.BillAmount = item.billAmount + item.fine;
                        trBillsList.Add(trBills);
                    }
                }
            }
            return View(trBillsList);
        }

        //public bool SendMessage(string receiver, string msg)
        //{
        //    bool status = false;
        //    var results = SMS.Send(new SMS.SMSRequest
        //    {
        //        from = Configuration.Instance.Settings["appsettings:NEXMO_FROM_NUMBER"],
        //        to = "918790201722",
        //        text = msg
        //    });
        //    return status;
        //}

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login");
        }

        public void sendEmail(string receiver, string subject, string message)
        {
           
            string email1 = "yashwanth-reddy.pasunoori@capgemini.com";
            string password = "yashwuu0943@";

            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.outlook.com");
            //SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

            mail.From = new MailAddress(email1, "Admin");
            mail.To.Add(receiver);
            mail.Subject = subject;

            string body = message;
            mail.Body = body;
            mail.IsBodyHtml = true;
            //SmtpServer.UseDefaultCredentials = false;
            SmtpServer.Port = 25;
            SmtpServer.Credentials = new System.Net.NetworkCredential(email1, password);
            SmtpServer.EnableSsl = true;
            SmtpServer.Send(mail);
        }

        [HttpPost]
        public JsonResult IsAlreadyExists(string email)
        {
            return Json(IsEmailAvailable(email));
        }

        public bool IsEmailAvailable(string email)
        {
            bool status = true;
            var EmailExists = db.CustomerDetails.Where(a => a.email.ToUpper() == email.ToUpper()).FirstOrDefault();
            if (EmailExists != null)
            {
                status = false;
                return status;
            }
            return status;
        }

    }
}